import javax.mail.*;
import javax.mail.internet.*;

import toolkit.mail.Postman;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class Main
{
    public static void main(String[] args)
        throws Exception
    {
        Postman postman = Postman.google(
            "tendryrambao@gmail.com",
            "foqf rglo xdab doqc"
        );
        // Postman postman = new Postman("localhost", 1025).authenticate();

        postman.createComposedMessage()
                    .to("zotinafiti@gmail.com")
                    .subject("Test Email via Gmail SMTP")
                    .addHTML(Files.readString(Path.of("index.html")))
                    .attach(new File("image.jpg"), "image-0")
                    .send();

        System.out.println("Email sent successfully via Gmail SMTP!");
    }
}
